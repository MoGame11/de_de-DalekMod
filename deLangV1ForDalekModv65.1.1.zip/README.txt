version 1.0 | 22/9/14
for dalekmod-v65.1.1